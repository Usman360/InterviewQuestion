import UIKit

var greeting = "Hello, playground"

// MARK: Delegates

/*
In Swift, a delegate is a design pattern that allows one object to act on behalf of another object. Delegation is a way to communicate between objects
*/

/*
 1: 
 Protocol: First, you define a protocol that lists the methods and properties that the delegate (another object) should implement. For example:
*/

protocol MyDelegate {
    func didSomething()
    func didReceiveData(data: Any)
}

/*
 2: 
 Delegate Property: Then, in the class that needs to delegate tasks, you declare a delegate property of the protocol type:
*/

class MyClass {
    var delegate: MyDelegate?
    
   // 3:  Delegate Methods: Within MyClass, you can call methods on the delegate to notify it of certain events or ask it to perform tasks:
    
    func performTask() {
        // Do some work...
        delegate?.didSomething()
    }
}
/*
 4:
 Delegate Conformance: Another class, typically a ViewController or another object, can conform to the MyDelegate protocol and implement its methods:
 */
class AnotherClass: MyDelegate {
    func didSomething() {
        // Handle the event when something happened
        print("Do Something")
    }
    
    func didReceiveData(data: Any) {
        // Handle received data
    }
}
/*
 5:
 Setting the Delegate: Finally, you set an instance of AnotherClass (or any other class conforming to the protocol) as the delegate of MyClass:
 */

let myInstance = MyClass()
let anotherInstance = AnotherClass()
myInstance.delegate = anotherInstance
myInstance.performTask()

// MARK: VIPER
/*
 VIPER is an application architecture for iOS and macOS applications. It stands for View, Interactor, Presenter, Entity, and Router. VIPER is an acronym that represents the core components of this architecture. Each component has a specific role in organizing the code and responsibilities within an application.

 Here's a brief overview of each component in the VIPER architecture:

 1: View: The View is responsible for displaying the user interface and handling user interactions. It sends user inputs to the Presenter and displays data received from the Presenter. In the context of iOS development, Views are often implemented as UIView subclasses.

 2: Interactor: The Interactor contains the business logic of the application. It is responsible for retrieving and manipulating data. Interactors receive requests from Presenters, perform the necessary operations (such as fetching data from a database or a network), and send the results back to the Presenter.

 3: Presenter: The Presenter acts as an intermediary between the View and the Interactor. It receives user inputs from the View, processes them (which might involve calling methods on the Interactor), and updates the View with the results. The Presenter also formats the data to be displayed in the View.

 4: Entity: The Entity represents the data model of the application. It encapsulates the data and business logic related to the application's entities (e.g., User, Product). Entities are typically simple objects that do not contain any UI-related code.

 5: Router: The Router handles the navigation logic of the application. It is responsible for transitioning from one module (VIPER set) to another, often dealing with navigation controllers and presenting new views.
 */

// MARK:

var Number1 = -32
var Number2 = 54

(Number1, Number2) = (Number2, Number1)

print("\nNumber 1 after swapping:", Number1)
print("Number 2 after swapping:", Number2)
// MARK:


protocol MyProtocol {
    static var defaultValue: Self { get }
}
struct MyStruct: MyProtocol {
    
    
    static var defaultValue: MyStruct {
        return MyStruct()
    }
}
